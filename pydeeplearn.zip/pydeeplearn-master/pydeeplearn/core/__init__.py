import sys
sys.path.append('./pydeeplearn/core')
import layers, net, solve, numeric
__all__ = ['layers',  'net', 'solve', 'numeric']
