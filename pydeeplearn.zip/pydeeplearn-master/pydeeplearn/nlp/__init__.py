import sys
sys.path.append('./pydeeplearn/nlp')
import ptbtree, wordvectors
__all__ = ['ptbtree',  'wordvectors']
