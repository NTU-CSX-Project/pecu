import sys
sys.path.append('./pydeeplearn/net')
import cnn, rnn
__all__ = ['cnn',  'rnn']
